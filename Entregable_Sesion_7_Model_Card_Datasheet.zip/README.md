# Session 7 — Submission package

## Contents
- `model_card.md`: nine-section Model Card, research-stage and honestly marked as not yet validated.
- `datasheet.md`: seven-section Dataset Datasheet, research-stage and honestly marked as not yet collected.

## Alignment with slide 31
The professor requests a Model Card and a Dataset Datasheet for the student's own research, submitted as rendered Markdown or an Exercise 12 ZIP.

## Important limitation
This package is a research-specific **draft for review and completion**, not proof of trained-model performance or collected organizational data. Replace each `UNKNOWN`, `TO BE DEFINED`, `NOT EVALUATED` or similar marker with evidence as the doctoral research progresses. The original Colab exercises were not executed to produce empirical metrics for this proposal.

## References
- Mitchell et al. (2019). Model Cards for Model Reporting.
- Gebru et al. (2021). Datasheets for Datasets.
- UNMSM Session 7 slide deck and hands-on notebook.
